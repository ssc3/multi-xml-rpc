#include "version.h"

#include "xmlrpc-c/base.h"

unsigned int const xmlrpc_version_major = XMLRPC_VERSION_MAJOR;
unsigned int const xmlrpc_version_minor = XMLRPC_VERSION_MINOR;
unsigned int const xmlrpc_version_point = XMLRPC_VERSION_POINT;
